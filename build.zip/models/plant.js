"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Plant = /** @class */ (function () {
    function Plant(id, description, resource, status) {
        this.id = id;
        this.description = description;
        this.resource = resource;
        this.status = status;
    }
    return Plant;
}());
exports.Plant = Plant;
